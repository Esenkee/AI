# Лаб 11: Naive Bayes-ийг тэг дээрээс бичих (Алхам 1-4)
import math, re
from collections import Counter
import pandas as pd
from sklearn.model_selection import train_test_split

def tokenize(s):
    # жижиг үсэг болгож, латин үсэг/тоо/$/%/' -аас бүрдсэн token гаргана
    return re.findall(r"[a-z0-9$%']+", s.lower())

class NaiveBayes:
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def fit(self, texts, labels):
        # prior, анги тус бүрийн үгийн Counter, үгсийн санг бүрдүүлнэ
        self.classes = sorted(set(labels))
        n = len(labels)
        self.prior = {c: sum(1 for l in labels if l == c) / n for c in self.classes}
        self.counts = {c: Counter() for c in self.classes}
        for t, l in zip(texts, labels):
            self.counts[l].update(tokenize(t))
        self.total = {c: sum(self.counts[c].values()) for c in self.classes}
        self.vocab = set().union(*[set(self.counts[c]) for c in self.classes])
        self.V = len(self.vocab)
        return self

    def log_score(self, text, c):
        # log P(c) + sum log P(w|c); үгсийн санд байхгүй үгийг алгасна
        s = math.log(self.prior[c])
        for w in tokenize(text):
            if w not in self.vocab:
                continue
            s += math.log((self.counts[c][w] + self.alpha) /
                          (self.total[c] + self.alpha * self.V))
        return s

    def predict_proba_spam(self, text):
        # хоёр ангийн оноог нормчилж spam-ын магадлал гаргана
        a, b = self.log_score(text, 'spam'), self.log_score(text, 'ham')
        m = max(a, b)
        return math.exp(a - m) / (math.exp(a - m) + math.exp(b - m))

    def predict(self, text):
        return max(self.classes, key=lambda c: self.log_score(text, c))

if __name__ == '__main__':
    # ---- Алхам 2: жижиг жишээ (гар тооцоог шалгах) ----
    toy = [('spam','free money now'),('spam','win free prize now'),('spam','free gift'),
           ('ham','meeting at noon'),('ham','project meeting now'),('ham','lunch at noon')]
    m = NaiveBayes(1.0).fit([t for _, t in toy], [l for l, _ in toy])
    print('V =', m.V, 'total =', m.total)
    for e in ['free now', 'meeting now', 'free meeting']:
        print(e, '-> P(spam) =', round(m.predict_proba_spam(e), 4))

    # ---- Алхам 1: өгөгдөл судлах ----
    df = pd.read_csv('spam_emails_en.csv')
    print(df.shape); print(df['label'].value_counts())
    df['n_words'] = df['text'].str.split().str.len()
    print(df.groupby('label')['n_words'].mean())
    print(df.loc[df['n_words'].idxmax()])
    print(df.sample(10, random_state=0))

    # ---- Алхам 3: token болгох, 80/20 хуваалт ----
    train, test = train_test_split(df, test_size=0.2, random_state=42, stratify=df['label'])
    print(len(train), len(test), test['label'].value_counts().to_dict())
    print('Train vocab:', len({w for t in train['text'] for w in tokenize(t)}))
    print(tokenize('YOU WON $1,000,000!!! Click NOW'))

    # ---- Алхам 4: fit / predict ----
    nb = NaiveBayes(1.0).fit(train['text'], list(train['label']))
    pred = [nb.predict(t) for t in test['text']]
    print('accuracy =', sum(p == l for p, l in zip(pred, test['label'])) / len(test))
    for e in ['Congratulations winner, click the link to claim your free prize',
              'What time does the database class start tomorrow',
              'There is a discount book sale on campus, want to go together']:
        print(nb.predict(e), round(nb.predict_proba_spam(e), 4), '|', e)
    # underflow: шууд үржвэр
    print(0.001 ** 200, 0.001 ** 200 == 0.0, 200 * math.log(0.001))
