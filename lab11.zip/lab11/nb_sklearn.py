# Лаб 11: scikit-learn-тэй харьцуулах, хэмжүүр, алдааны шинжилгээ (Алхам 5-9, нэмэлт)
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB, BernoulliNB
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support, accuracy_score
from nb_scratch import NaiveBayes

df = pd.read_csv('spam_emails_en.csv')
train, test = train_test_split(df, test_size=0.2, random_state=42, stratify=df['label'])
TP = r"[a-z0-9$%']+"
cv = CountVectorizer(token_pattern=TP)
Xtr = cv.fit_transform(train['text']); Xte = cv.transform(test['text'])   # fit зөвхөн train
clf = MultinomialNB(alpha=1.0).fit(Xtr, train['label'])
pred = clf.predict(Xte)
print('sklearn acc', (pred == test['label']).mean(), Xtr.shape)

# Алхам 5: өөрийн хэрэгжүүлэлттэй таарч буй хувь
mine = NaiveBayes(1.0).fit(train['text'], list(train['label']))
mp = np.array([mine.predict(t) for t in test['text']])
print('agreement', (mp == pred).mean())

# Алхам 6: confusion matrix, гар томьёо, alpha харьцуулалт
cm = confusion_matrix(test['label'], pred, labels=['ham', 'spam']); print(cm)
tn, fp, fn, tp = cm.ravel()
P = tp / (tp + fp); R = tp / (tp + fn); print('manual', P, R, 2 * P * R / (P + R))
print('sklearn', precision_recall_fscore_support(test['label'], pred, pos_label='spam', average='binary')[:3])
for a in [0.01, 1, 5]:
    p = MultinomialNB(alpha=a).fit(Xtr, train['label']).predict(Xte)
    pr, rc, f, _ = precision_recall_fscore_support(test['label'], p, pos_label='spam', average='binary')
    print(a, accuracy_score(test['label'], p), pr, rc, f)

# Алхам 7: буруу ангилагдсан имэйлүүд
wrong = test[pred != test['label']].copy()
wrong['pred'] = pred[pred != test['label']]
pd.set_option('display.max_colwidth', 400); print(wrong)

# Алхам 8: итгэл ба онцлог үгс
proba = clf.predict_proba(Xte); si = list(clf.classes_).index('spam'); hi = 1 - si
print('max proba > 0.99:', (proba.max(axis=1) > 0.99).mean())
print(proba[pred != test['label']].round(4))
ratio = clf.feature_log_prob_[si] - clf.feature_log_prob_[hi]
vocab = np.array(cv.get_feature_names_out())
print(vocab[np.argsort(-ratio)[:8]]); print(vocab[np.argsort(ratio)[:8]])

# Алхам 9: BernoulliNB, TF-IDF
bn = BernoulliNB().fit(Xtr, train['label']); print('Bernoulli', bn.score(Xte, test['label']))
tf = TfidfVectorizer(token_pattern=TP); Ttr = tf.fit_transform(train['text'])
print('TFIDF', MultinomialNB().fit(Ttr, train['label']).score(tf.transform(test['text']), test['label']))
mine_emails = ['Quantum computer']   # өөрийн 10 имэйлээ энд нэм
for e in mine_emails:
    print(e, clf.predict(cv.transform([e])), clf.predict_proba(cv.transform([e])).round(3))

# Нэмэлт: босго ба зардал (10*FP + FN)
ps = proba[:, si]; y = (test['label'] == 'spam').values
for t in [0.5, 0.9, 0.99, 0.999, 0.9999]:
    yh = ps >= t; fp = (yh & ~y).sum(); fn = (~yh & y).sum(); tp = (yh & y).sum()
    print(t, tp / max(tp + fp, 1), tp / (tp + fn), 10 * fp + fn)
