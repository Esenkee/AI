# alarm.py - Alarm Байесийн сүлжээ (pgmpy). Алхам 1-6, 8
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD, State
from pgmpy.inference import VariableElimination
from pgmpy.sampling import BayesianModelSampling

# ---------- Алхам 1: Rain -> WetGrass ----------
print("=== Алхам 1 ===")
m1 = DiscreteBayesianNetwork([('Rain', 'WetGrass')])
cpd_rain = TabularCPD('Rain', 2, [[0.8], [0.2]])
cpd_wet = TabularCPD('WetGrass', 2,
                     [[0.9, 0.1],      # WetGrass=0 мөр: Rain=0, Rain=1 багана
                      [0.1, 0.9]],     # WetGrass=1 мөр
                     evidence=['Rain'], evidence_card=[2])
m1.add_cpds(cpd_rain, cpd_wet)
print("check_model:", m1.check_model())
q = VariableElimination(m1).query(['Rain'], evidence={'WetGrass': 1}, show_progress=False)
print("P(Rain=1 | WetGrass=1) =", round(q.values[1], 4), "(гараар 0.18/0.26 =", round(0.18/0.26, 4), ")")

# ---------- Алхам 2: бүтэц, параметрийн тоо ----------
print("\n=== Алхам 2 ===")
print("Бүтэн хамтарсан хүснэгт: 2^5 - 1 =", 2**5 - 1)
params = {'Burglary': 1, 'Earthquake': 1, 'Alarm': 4, 'JohnCalls': 2, 'MaryCalls': 2}
print("Сүлжээний параметр:", params, "нийт =", sum(params.values()))

# ---------- Алхам 3: Alarm сүлжээ ба CPT ----------
print("\n=== Алхам 3 ===")
model = DiscreteBayesianNetwork([('Burglary', 'Alarm'), ('Earthquake', 'Alarm'),
                                 ('Alarm', 'JohnCalls'), ('Alarm', 'MaryCalls')])
cpd_b = TabularCPD('Burglary', 2, [[0.999], [0.001]])
cpd_e = TabularCPD('Earthquake', 2, [[0.998], [0.002]])
# баганы дараалал: (B,E) = (0,0), (0,1), (1,0), (1,1)
cpd_a = TabularCPD('Alarm', 2,
                   [[1 - 0.001, 1 - 0.29, 1 - 0.94, 1 - 0.95],
                    [0.001,     0.29,     0.94,     0.95]],
                   evidence=['Burglary', 'Earthquake'], evidence_card=[2, 2])
cpd_j = TabularCPD('JohnCalls', 2, [[0.95, 0.10], [0.05, 0.90]],
                   evidence=['Alarm'], evidence_card=[2])
cpd_m = TabularCPD('MaryCalls', 2, [[0.99, 0.30], [0.01, 0.70]],
                   evidence=['Alarm'], evidence_card=[2])
model.add_cpds(cpd_b, cpd_e, cpd_a, cpd_j, cpd_m)
print("check_model:", model.check_model())
print(model.get_cpds('Alarm'))
print("nodes:", sorted(model.nodes()))
print("edges:", sorted(model.edges()))

infer = VariableElimination(model)
def P(var, evidence=None, state=1):
    return infer.query([var], evidence=evidence or {}, show_progress=False).values[state]

# ---------- Алхам 4: prior ----------
print("\n=== Алхам 4 ===")
for v in ['JohnCalls', 'MaryCalls', 'Alarm']:
    print(f"P({v}=1) = {P(v):.4f}")

# ---------- Алхам 5: posterior ----------
print("\n=== Алхам 5 ===")
rows = [
    ("P(B=1 | J=1)",           P('Burglary', {'JohnCalls': 1})),
    ("P(B=1 | J=1, M=1)",      P('Burglary', {'JohnCalls': 1, 'MaryCalls': 1})),
    ("P(E=1 | J=1, M=1)",      P('Earthquake', {'JohnCalls': 1, 'MaryCalls': 1})),
    ("P(A=1 | J=1, M=1)",      P('Alarm', {'JohnCalls': 1, 'MaryCalls': 1})),
    ("P(B=1 | J=1, M=0)",      P('Burglary', {'JohnCalls': 1, 'MaryCalls': 0})),
    ("P(J=1 | B=1)",           P('JohnCalls', {'Burglary': 1})),
]
for n, v in rows:
    print(f"{n} = {v:.4f}")

# ---------- Алхам 6: explaining away, хамаарал ----------
print("\n=== Алхам 6 ===")
print(f"P(B=1 | A=1)       = {P('Burglary', {'Alarm': 1}):.4f}")
print(f"P(B=1 | A=1, E=1)  = {P('Burglary', {'Alarm': 1, 'Earthquake': 1}):.4f}")
print(f"P(B=1 | A=1, E=0)  = {P('Burglary', {'Alarm': 1, 'Earthquake': 0}):.4f}")

def dep(a, b, obs=None):
    return b in model.active_trail_nodes(a, observed=obs)[a]

pairs = [("Burglary", "Earthquake", None), ("Burglary", "Earthquake", ['Alarm']),
         ("JohnCalls", "MaryCalls", None), ("JohnCalls", "MaryCalls", ['Alarm']),
         ("Burglary", "JohnCalls", ['Alarm'])]
for a, b, o in pairs:
    print(f"{a} - {b} | нотолгоо={o}: хамааралтай={dep(a, b, o)}")
print("local_independencies(JohnCalls):", model.local_independencies('JohnCalls'))

# ---------- Алхам 8: sampling ----------
print("\n=== Алхам 8 ===")
sampler = BayesianModelSampling(model)
# pgmpy-ийн rejection_sample нь хүлээн авах тоог биш, хүссэн тоогоор (size) түүвэр гаргадаг.
# Тиймээс rejection sampling-ийг өөрөө бичив: prior-оор түүвэрлээд нотолгоотой таарахыг үлдээнэ.
for n in (1000, 10000, 100000):
    data = sampler.forward_sample(size=n, seed=1, show_progress=False)
    acc = data[(data['JohnCalls'] == 1) & (data['MaryCalls'] == 1)]
    pb = acc['Burglary'].mean() if len(acc) else float('nan')
    print(f"N={n}: P(J=1)={data['JohnCalls'].mean():.4f}  хүлээн авсан={len(acc)}  P(B=1|J=1,M=1)={pb:.4f}")
