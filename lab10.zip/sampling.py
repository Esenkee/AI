from pgmpy.sampling import BayesianModelSampling
sampler = BayesianModelSampling(model)

for n in (1000, 10000, 100000):
    data = sampler.forward_sample(size=n, seed=1, show_progress=False)
    # rejection sampling: нотолгоотой таарахыг үлдээнэ
    acc = data[(data['JohnCalls'] == 1) & (data['MaryCalls'] == 1)]
    print(n, data['JohnCalls'].mean(), len(acc), acc['Burglary'].mean())