import itertools

# CPT-г dictionary болгов: P(хувьсагч=1 | эцэг)
P_B = 0.001
P_E = 0.002
P_A = {(1, 1): 0.95, (1, 0): 0.94, (0, 1): 0.29, (0, 0): 0.001}   # (b, e)
P_J = {1: 0.90, 0: 0.05}                                            # a
P_M = {1: 0.70, 0: 0.01}                                            # a

def bern(p1, x):
    """P(X=x), өгөгдсөн P(X=1)=p1"""
    return p1 if x == 1 else 1 - p1

def joint(b, e, a, j, m):
    """P(b,e,a,j,m) = P(b)P(e)P(a|b,e)P(j|a)P(m|a)"""
    return (bern(P_B, b) * bern(P_E, e) * bern(P_A[(b, e)], a)
            * bern(P_J[a], j) * bern(P_M[a], m))

VARS = ['B', 'E', 'A', 'J', 'M']

def query(var, evidence):
    """P(var=1 | evidence): 32 хослол давтаж, нотолгоотой зөрчилдсөнийг алгасаад
    нийлбэрлэж, нормчилно"""
    totals = {0: 0.0, 1: 0.0}
    for values in itertools.product([0, 1], repeat=5):   # 1. 32 хослол
        assign = dict(zip(VARS, values))
        if any(assign[k] != v for k, v in evidence.items()):   # 2. зөрчилдсөнийг алга
            continue
        totals[assign[var]] += joint(*values)            # 3. төлөв тус бүрээр нийлбэр
    return totals[1] / (totals[0] + totals[1])           # 4. нормчилно

print(query('B', {'J': 1, 'M': 1}))   # 0.2842
print(query('J', {}))                 # 0.0521