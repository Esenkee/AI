from pgmpy.models import DiscreteBayesianNetwork # хуучин хувилбарт:
#BayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination
model = DiscreteBayesianNetwork([('Rain', 'WetGrass')])
cpd_rain = TabularCPD('Rain', 2, [[0.8], [0.2]])
cpd_wet = TabularCPD('WetGrass', 2,
 [[0.9, 0.1], # WetGrass=0 мөр: Rain=0, Rain=1
#багана
 [0.1, 0.9]], # WetGrass=1 мөр
 evidence=['Rain'], evidence_card=[2])
model.add_cpds(cpd_rain, cpd_wet)
print(model.check_model())
print(VariableElimination(model).query(['Rain'], evidence={'WetGrass':
1}))